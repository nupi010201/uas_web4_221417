# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| >= 1.5.x| :white_check_mark: |
| < 1.5.0 | :x:                |

## Reporting a Vulnerability

Just [create new issue](https://github.com/ikhsan3adi/absensi-sekolah-qr-code/issues).
