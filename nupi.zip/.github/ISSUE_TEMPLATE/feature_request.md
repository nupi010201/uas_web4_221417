---
name: Feature Request
about: Permintaan penambahan fitur baru
title: "[FEAT-REQ]"
labels: feature-request
assignees: 

---

**Jelaskan fitur baru tersebut**


**Screenshots**
Jika ada

