---
name: Bug report
about: Laporkan penemuan bug
title: "[BUG]"
labels: bug
assignees: ikhsan3adi

---

**Jelaskan bug tersebut**


**Screenshots**
Jika ada


**Versi yang digunakan**
Tuliskan versi yang didownload (contoh: v1.5.3). Jika download via zip/clone berikan informasi waktu saat download source code.

**Versi PHP**
Contoh PHP 8.2