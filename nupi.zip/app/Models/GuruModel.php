<?php

namespace App\Models;

use CodeIgniter\Model;

class dosenModel extends Model
{
   protected $allowedFields = [
      'nuptk',
      'nama_dosen',
      'jenis_kelamin',
      'alamat',
      'no_hp',
      'unique_code'
   ];

   protected $table = 'tb_dosen';

   protected $primaryKey = 'id_dosen';

   public function cekdosen(string $unique_code)
   {
      return $this->where(['unique_code' => $unique_code])->first();
   }

   public function getAlldosen()
   {
      return $this->orderBy('nama_dosen')->findAll();
   }

   public function getdosenById($id)
   {
      return $this->where([$this->primaryKey => $id])->first();
   }

   public function createdosen($nuptk, $nama, $jenisKelamin, $alamat, $noHp)
   {
      return $this->save([
         'nuptk' => $nuptk,
         'nama_dosen' => $nama,
         'jenis_kelamin' => $jenisKelamin,
         'alamat' => $alamat,
         'no_hp' => $noHp,
         'unique_code' => sha1($nama . md5($nuptk . $nama . $noHp)) . substr(sha1($nuptk . rand(0, 100)), 0, 24)
      ]);
   }

   public function updatedosen($id, $nuptk, $nama, $jenisKelamin, $alamat, $noHp)
   {
      return $this->save([
         $this->primaryKey => $id,
         'nuptk' => $nuptk,
         'nama_dosen' => $nama,
         'jenis_kelamin' => $jenisKelamin,
         'alamat' => $alamat,
         'no_hp' => $noHp,
      ]);
   }
}
