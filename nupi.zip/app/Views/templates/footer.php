<footer class="footer">
   <div class="container-fluid">
      <nav class="float-left">
         <ul>
            <li>
               <a href="https://www.instagram.com/ikhsan3adi/">
                  Instagram
               </a>
            </li>
         </ul>
      </nav>
      <div class="copyright float-right">
         <?= $generalSettings->copyright; ?>
      </div>
   </div>
</footer>