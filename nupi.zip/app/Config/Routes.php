<?php

namespace Config;

use CodeIgniter\Router\RouteCollection;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.

// Scan
$routes->get('/', 'Scan::index');

$routes->group('scan', function (RouteCollection $routes) {
   $routes->get('', 'Scan::index');
   $routes->get('masuk', 'Scan::index/Masuk');
   $routes->get('pulang', 'Scan::index/Pulang');

   $routes->post('cek', 'Scan::cekKode');
});



// Admin
$routes->group('admin', function (RouteCollection $routes) {
   // Admin dashboard
   $routes->get('', 'Admin\Dashboard::index');
   $routes->get('dashboard', 'Admin\Dashboard::index');

   // Kelas
   $routes->group('kelas', ['namespace' => 'App\Controllers\Admin'], function ($routes) {
      $routes->get('/', 'KelasController::index');
      $routes->get('tambah', 'KelasController::tambahKelas');
      $routes->post('tambahKelasPost', 'KelasController::tambahKelasPost');
      $routes->get('edit/(:any)', 'KelasController::editKelas/$1');
      $routes->post('editKelasPost', 'KelasController::editKelasPost');
      $routes->post('deleteKelasPost', 'KelasController::deleteKelasPost');
      $routes->post('list-data', 'KelasController::listData');
   });

   // Jurusan
   $routes->group('jurusan', ['namespace' => 'App\Controllers\Admin'], function ($routes) {
      $routes->get('/', 'JurusanController::index');
      $routes->get('tambah', 'JurusanController::tambahJurusan');
      $routes->post('tambahJurusanPost', 'JurusanController::tambahJurusanPost');
      $routes->get('edit/(:any)', 'JurusanController::editJurusan/$1');
      $routes->post('editJurusanPost', 'JurusanController::editJurusanPost');
      $routes->post('deleteJurusanPost', 'JurusanController::deleteJurusanPost');
      $routes->post('list-data', 'JurusanController::listData');
   });

   // admin lihat data mahasiswa
   $routes->get('mahasiswa', 'Admin\Datamahasiswa::index');
   $routes->post('mahasiswa', 'Admin\Datamahasiswa::ambilDatamahasiswa');
   // admin tambah data mahasiswa
   $routes->get('mahasiswa/create', 'Admin\Datamahasiswa::formTambahmahasiswa');
   $routes->post('mahasiswa/create', 'Admin\Datamahasiswa::savemahasiswa');
   // admin edit data mahasiswa
   $routes->get('mahasiswa/edit/(:any)', 'Admin\Datamahasiswa::formEditmahasiswa/$1');
   $routes->post('mahasiswa/edit', 'Admin\Datamahasiswa::updatemahasiswa');
   // admin hapus data mahasiswa
   $routes->delete('mahasiswa/delete/(:any)', 'Admin\Datamahasiswa::delete/$1');
   $routes->get('mahasiswa/bulk', 'Admin\Datamahasiswa::bulkPostmahasiswa');

   // POST Data mahasiswa

   $routes->group('mahasiswa', ['namespace' => 'App\Controllers\Admin'], function ($routes) {
      $routes->post('downloadCSVFilePost', 'Datamahasiswa::downloadCSVFilePost');
      $routes->post('generateCSVObjectPost', 'Datamahasiswa::generateCSVObjectPost');
      $routes->post('importCSVItemPost', 'Datamahasiswa::importCSVItemPost');
      $routes->post('deleteSelectedmahasiswa', 'Datamahasiswa::deleteSelectedmahasiswa');
   });


   // admin lihat data dosen
   $routes->get('dosen', 'Admin\Datadosen::index');
   $routes->post('dosen', 'Admin\Datadosen::ambilDatadosen');
   // admin tambah data dosen
   $routes->get('dosen/create', 'Admin\Datadosen::formTambahdosen');
   $routes->post('dosen/create', 'Admin\Datadosen::savedosen');
   // admin edit data dosen
   $routes->get('dosen/edit/(:any)', 'Admin\Datadosen::formEditdosen/$1');
   $routes->post('dosen/edit', 'Admin\Datadosen::updatedosen');
   // admin hapus data dosen
   $routes->delete('dosen/delete/(:any)', 'Admin\Datadosen::delete/$1');


   // admin lihat data absen mahasiswa
   $routes->get('absen-mahasiswa', 'Admin\DataAbsenmahasiswa::index');
   $routes->post('absen-mahasiswa', 'Admin\DataAbsenmahasiswa::ambilDatamahasiswa'); // ambil mahasiswa berdasarkan kelas dan tanggal
   $routes->post('absen-mahasiswa/kehadiran', 'Admin\DataAbsenmahasiswa::ambilKehadiran'); // ambil kehadiran mahasiswa
   $routes->post('absen-mahasiswa/edit', 'Admin\DataAbsenmahasiswa::ubahKehadiran'); // ubah kehadiran mahasiswa

   // admin lihat data absen dosen
   $routes->get('absen-dosen', 'Admin\DataAbsendosen::index');
   $routes->post('absen-dosen', 'Admin\DataAbsendosen::ambilDatadosen'); // ambil dosen berdasarkan tanggal
   $routes->post('absen-dosen/kehadiran', 'Admin\DataAbsendosen::ambilKehadiran'); // ambil kehadiran dosen
   $routes->post('absen-dosen/edit', 'Admin\DataAbsendosen::ubahKehadiran'); // ubah kehadiran dosen

   // admin generate QR
   $routes->get('generate', 'Admin\GenerateQR::index');
   $routes->post('generate/mahasiswa-by-kelas', 'Admin\GenerateQR::getmahasiswaByKelas'); // ambil mahasiswa berdasarkan kelas

   // Generate QR
   $routes->post('generate/mahasiswa', 'Admin\QRGenerator::generateQrmahasiswa');
   $routes->post('generate/dosen', 'Admin\QRGenerator::generateQrdosen');

   // Download QR
   $routes->get('qr/mahasiswa/download', 'Admin\QRGenerator::downloadAllQrmahasiswa');
   $routes->get('qr/mahasiswa/(:any)/download', 'Admin\QRGenerator::downloadQrmahasiswa/$1');
   $routes->get('qr/dosen/download', 'Admin\QRGenerator::downloadAllQrdosen');
   $routes->get('qr/dosen/(:any)/download', 'Admin\QRGenerator::downloadQrdosen/$1');

   // admin buat laporan
   $routes->get('laporan', 'Admin\GenerateLaporan::index');
   $routes->post('laporan/mahasiswa', 'Admin\GenerateLaporan::generateLaporanmahasiswa');
   $routes->post('laporan/dosen', 'Admin\GenerateLaporan::generateLaporandosen');

   // superadmin lihat data petugas
   $routes->get('petugas', 'Admin\DataPetugas::index');
   $routes->post('petugas', 'Admin\DataPetugas::ambilDataPetugas');
   // superadmin tambah data petugas
   $routes->get('petugas/register', 'Admin\DataPetugas::registerPetugas');
   // superadmin edit data petugas
   $routes->get('petugas/edit/(:any)', 'Admin\DataPetugas::formEditPetugas/$1');
   $routes->post('petugas/edit', 'Admin\DataPetugas::updatePetugas');
   // superadmin hapus data petugas
   $routes->delete('petugas/delete/(:any)', 'Admin\DataPetugas::delete/$1');

   // Settings
   $routes->group('general-settings', ['namespace' => 'App\Controllers\Admin'], function ($routes) {
      $routes->get('/', 'GeneralSettings::index');
      $routes->post('update', 'GeneralSettings::generalSettingsPost');
   });
});


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
   require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
