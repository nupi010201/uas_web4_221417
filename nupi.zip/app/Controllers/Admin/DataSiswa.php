<?php

namespace App\Controllers\Admin;

use App\Models\mahasiswaModel;
use App\Models\KelasModel;

use App\Controllers\BaseController;
use App\Models\JurusanModel;
use App\Models\UploadModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class Datamahasiswa extends BaseController
{
   protected mahasiswaModel $mahasiswaModel;
   protected KelasModel $kelasModel;
   protected JurusanModel $jurusanModel;

   protected $mahasiswaValidationRules = [
      'nis' => [
         'rules' => 'required|max_length[20]|min_length[4]',
         'errors' => [
            'required' => 'NIS harus diisi.',
            'is_unique' => 'NIS ini telah terdaftar.',
            'min_length[4]' => 'Panjang NIS minimal 4 karakter'
         ]
      ],
      'nama' => [
         'rules' => 'required|min_length[3]',
         'errors' => [
            'required' => 'Nama harus diisi'
         ]
      ],
      'id_kelas' => [
         'rules' => 'required',
         'errors' => [
            'required' => 'Kelas harus diisi'
         ]
      ],
      'jk' => ['rules' => 'required', 'errors' => ['required' => 'Jenis kelamin wajib diisi']],
      'no_hp' => 'required|numeric|max_length[20]|min_length[5]'
   ];

   public function __construct()
   {
      $this->mahasiswaModel = new mahasiswaModel();
      $this->kelasModel = new KelasModel();
      $this->jurusanModel = new JurusanModel();
   }

   public function index()
   {
      $data = [
         'title' => 'Data mahasiswa',
         'ctx' => 'mahasiswa',
         'kelas' => $this->kelasModel->getDataKelas(),
         'jurusan' => $this->jurusanModel->getDataJurusan()
      ];

      return view('admin/data/data-mahasiswa', $data);
   }

   public function ambilDatamahasiswa()
   {
      $kelas = $this->request->getVar('kelas') ?? null;
      $jurusan = $this->request->getVar('jurusan') ?? null;

      $result = $this->mahasiswaModel->getAllmahasiswaWithKelas($kelas, $jurusan);

      $data = [
         'data' => $result,
         'empty' => empty($result)
      ];

      return view('admin/data/list-data-mahasiswa', $data);
   }

   public function formTambahmahasiswa()
   {
      $kelas = $this->kelasModel->getDataKelas();

      $data = [
         'ctx' => 'mahasiswa',
         'kelas' => $kelas,
         'title' => 'Tambah Data mahasiswa'
      ];

      return view('admin/data/create/create-data-mahasiswa', $data);
   }

   public function savemahasiswa()
   {
      // validasi
      if (!$this->validate($this->mahasiswaValidationRules)) {
         $kelas = $this->kelasModel->getDataKelas();

         $data = [
            'ctx' => 'mahasiswa',
            'kelas' => $kelas,
            'title' => 'Tambah Data mahasiswa',
            'validation' => $this->validator,
            'oldInput' => $this->request->getVar()
         ];
         return view('/admin/data/create/create-data-mahasiswa', $data);
      }

      // simpan
      $result = $this->mahasiswaModel->createmahasiswa(
         nis: $this->request->getVar('nis'),
         nama: $this->request->getVar('nama'),
         idKelas: intval($this->request->getVar('id_kelas')),
         jenisKelamin: $this->request->getVar('jk'),
         noHp: $this->request->getVar('no_hp'),
      );

      if ($result) {
         session()->setFlashdata([
            'msg' => 'Tambah data berhasil',
            'error' => false
         ]);
         return redirect()->to('/admin/mahasiswa');
      }

      session()->setFlashdata([
         'msg' => 'Gagal menambah data',
         'error' => true
      ]);
      return redirect()->to('/admin/mahasiswa/create');
   }

   public function formEditmahasiswa($id)
   {
      $mahasiswa = $this->mahasiswaModel->getmahasiswaById($id);
      $kelas = $this->kelasModel->getDataKelas();

      if (empty($mahasiswa) || empty($kelas)) {
         throw new PageNotFoundException('Data mahasiswa dengan id ' . $id . ' tidak ditemukan');
      }

      $data = [
         'data' => $mahasiswa,
         'kelas' => $kelas,
         'ctx' => 'mahasiswa',
         'title' => 'Edit mahasiswa',
      ];

      return view('admin/data/edit/edit-data-mahasiswa', $data);
   }

   public function updatemahasiswa()
   {
      $idmahasiswa = $this->request->getVar('id');

      $mahasiswaLama = $this->mahasiswaModel->getmahasiswaById($idmahasiswa);

      if ($mahasiswaLama['nis'] != $this->request->getVar('nis')) {
         $this->mahasiswaValidationRules['nis']['rules'] = 'required|max_length[20]|min_length[4]|is_unique[tb_mahasiswa.nis]';
      }

      // validasi
      if (!$this->validate($this->mahasiswaValidationRules)) {
         $mahasiswa = $this->mahasiswaModel->getmahasiswaById($idmahasiswa);
         $kelas = $this->kelasModel->getDataKelas();

         $data = [
            'data' => $mahasiswa,
            'kelas' => $kelas,
            'ctx' => 'mahasiswa',
            'title' => 'Edit mahasiswa',
            'validation' => $this->validator,
            'oldInput' => $this->request->getVar()
         ];
         return view('/admin/data/edit/edit-data-mahasiswa', $data);
      }

      // update
      $result = $this->mahasiswaModel->updatemahasiswa(
         id: $idmahasiswa,
         nis: $this->request->getVar('nis'),
         nama: $this->request->getVar('nama'),
         idKelas: intval($this->request->getVar('id_kelas')),
         jenisKelamin: $this->request->getVar('jk'),
         noHp: $this->request->getVar('no_hp'),
      );

      if ($result) {
         session()->setFlashdata([
            'msg' => 'Edit data berhasil',
            'error' => false
         ]);
         return redirect()->to('/admin/mahasiswa');
      }

      session()->setFlashdata([
         'msg' => 'Gagal mengubah data',
         'error' => true
      ]);
      return redirect()->to('/admin/mahasiswa/edit/' . $idmahasiswa);
   }

   public function delete($id)
   {
      $result = $this->mahasiswaModel->delete($id);

      if ($result) {
         session()->setFlashdata([
            'msg' => 'Data berhasil dihapus',
            'error' => false
         ]);
         return redirect()->to('/admin/mahasiswa');
      }

      session()->setFlashdata([
         'msg' => 'Gagal menghapus data',
         'error' => true
      ]);
      return redirect()->to('/admin/mahasiswa');
   }

   /**
    * Delete Selected Posts
    */
   public function deleteSelectedmahasiswa()
   {
      $mahasiswaIds = inputPost('mahasiswa_ids');
      $this->mahasiswaModel->deleteMultiSelected($mahasiswaIds);
   }

   /*
    *-------------------------------------------------------------------------------------------------
    * IMPORT mahasiswa
    *-------------------------------------------------------------------------------------------------
    */

   /**
    * Bulk Post Upload
    */
   public function bulkPostmahasiswa()
   {
      $data['title'] = 'Import mahasiswa';
      $data['ctx'] = 'mahasiswa';
      $data['kelas'] = $this->kelasModel->getDataKelas();

      return view('/admin/data/import-mahasiswa', $data);
   }

   /**
    * Generate CSV Object Post
    */
   public function generateCSVObjectPost()
   {
      $uploadModel = new UploadModel();
      //delete old txt files
      $files = glob(FCPATH . 'uploads/tmp/*.txt');
      if (!empty($files)) {
         foreach ($files as $item) {
            @unlink($item);
         }
      }
      $file = $uploadModel->uploadCSVFile('file');
      if (!empty($file) && !empty($file['path'])) {
         $obj = $this->mahasiswaModel->generateCSVObject($file['path']);
         if (!empty($obj)) {
            $data = [
               'result' => 1,
               'numberOfItems' => $obj->numberOfItems,
               'txtFileName' => $obj->txtFileName,
            ];
            echo json_encode($data);
            exit();
         }
      }
      echo json_encode(['result' => 0]);
   }

   /**
    * Import CSV Item Post
    */
   public function importCSVItemPost()
   {
      $txtFileName = inputPost('txtFileName');
      $index = inputPost('index');
      $mahasiswa = $this->mahasiswaModel->importCSVItem($txtFileName, $index);
      if (!empty($mahasiswa)) {
         $data = [
            'result' => 1,
            'mahasiswa' => $mahasiswa,
            'index' => $index
         ];
         echo json_encode($data);
      } else {
         $data = [
            'result' => 0,
            'index' => $index
         ];
         echo json_encode($data);
      }
   }

   /**
    * Download CSV File Post
    */
   public function downloadCSVFilePost()
   {
      $submit = inputPost('submit');
      $response = \Config\Services::response();
      if ($submit == 'csv_mahasiswa_template') {
         return $response->download(FCPATH . 'assets/file/csv_mahasiswa_template.csv', null);
      } elseif ($submit == 'csv_dosen_template') {
         return $response->download(FCPATH . 'assets/file/csv_dosen_template.csv', null);
      }
   }
}
