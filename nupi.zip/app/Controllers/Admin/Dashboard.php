<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

use App\Models\dosenModel;
use App\Models\mahasiswaModel;
use App\Models\KelasModel;
use App\Models\PetugasModel;
use App\Models\PresensidosenModel;
use App\Models\PresensimahasiswaModel;
use CodeIgniter\I18n\Time;
use Config\AbsensiSekolah as ConfigAbsensiSekolah;

class Dashboard extends BaseController
{
   protected mahasiswaModel $mahasiswaModel;
   protected dosenModel $dosenModel;

   protected KelasModel $KelasModel;

   protected PresensimahasiswaModel $presensimahasiswaModel;
   protected PresensidosenModel $presensidosenModel;

   protected PetugasModel $petugasModel;

   public function __construct()
   {
      $this->mahasiswaModel = new mahasiswaModel();
      $this->dosenModel = new dosenModel();
      $this->KelasModel = new KelasModel();
      $this->presensimahasiswaModel = new PresensimahasiswaModel();
      $this->presensidosenModel = new PresensidosenModel();
      $this->petugasModel = new PetugasModel();
   }

   public function index()
   {
      $now = Time::now();

      $dateRange = [];
      $mahasiswaKehadiranArray = [];
      $dosenKehadiranArray = [];

      for ($i = 6; $i >= 0; $i--) {
         $date = $now->subDays($i)->toDateString();
         if ($i == 0) {
            $formattedDate = "Hari ini";
         } else {
            $t = $now->subDays($i);
            $formattedDate = "{$t->getDay()} " . substr($t->toFormattedDateString(), 0, 3);
         }
         array_push($dateRange, $formattedDate);
         array_push(
            $mahasiswaKehadiranArray,
            count($this->presensimahasiswaModel
               ->join('tb_mahasiswa', 'tb_presensi_mahasiswa.id_mahasiswa = tb_mahasiswa.id_mahasiswa', 'left')
               ->where(['tb_presensi_mahasiswa.tanggal' => "$date", 'tb_presensi_mahasiswa.id_kehadiran' => '1'])->findAll())
         );
         array_push(
            $dosenKehadiranArray,
            count($this->presensidosenModel
               ->join('tb_dosen', 'tb_presensi_dosen.id_dosen = tb_dosen.id_dosen', 'left')
               ->where(['tb_presensi_dosen.tanggal' => "$date", 'tb_presensi_dosen.id_kehadiran' => '1'])->findAll())
         );
      }

      $today = $now->toDateString();

      $data = [
         'title' => 'Dashboard',
         'ctx' => 'dashboard',

         'mahasiswa' => $this->mahasiswaModel->getAllmahasiswaWithKelas(),
         'dosen' => $this->dosenModel->getAlldosen(),

         'kelas' => $this->KelasModel->getDataKelas(),

         'dateRange' => $dateRange,
         'dateNow' => $now->toLocalizedString('d MMMM Y'),

         'grafikKehadiranmahasiswa' => $mahasiswaKehadiranArray,
         'grafikkKehadirandosen' => $dosenKehadiranArray,

         'jumlahKehadiranmahasiswa' => [
            'hadir' => count($this->presensimahasiswaModel->getPresensiByKehadiran('1', $today)),
            'sakit' => count($this->presensimahasiswaModel->getPresensiByKehadiran('2', $today)),
            'izin' => count($this->presensimahasiswaModel->getPresensiByKehadiran('3', $today)),
            'alfa' => count($this->presensimahasiswaModel->getPresensiByKehadiran('4', $today))
         ],

         'jumlahKehadirandosen' => [
            'hadir' => count($this->presensidosenModel->getPresensiByKehadiran('1', $today)),
            'sakit' => count($this->presensidosenModel->getPresensiByKehadiran('2', $today)),
            'izin' => count($this->presensidosenModel->getPresensiByKehadiran('3', $today)),
            'alfa' => count($this->presensidosenModel->getPresensiByKehadiran('4', $today))
         ],

         'petugas' => $this->petugasModel->getAllPetugas(),
      ];

      return view('admin/dashboard', $data);
   }
}
