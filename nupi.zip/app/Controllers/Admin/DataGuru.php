<?php

namespace App\Controllers\Admin;

use App\Models\dosenModel;

use App\Controllers\BaseController;
use CodeIgniter\Exceptions\PageNotFoundException;

class Datadosen extends BaseController
{
   protected dosenModel $dosenModel;

   protected $dosenValidationRules = [
      'nuptk' => [
         'rules' => 'required|max_length[20]|min_length[16]',
         'errors' => [
            'required' => 'NUPTK harus diisi.',
            'is_unique' => 'NUPTK ini telah terdaftar.',
            'min_length[16]' => 'Panjang NUPTK minimal 16 karakter'
         ]
      ],
      'nama' => [
         'rules' => 'required|min_length[3]',
         'errors' => [
            'required' => 'Nama harus diisi'
         ]
      ],
      'jk' => ['rules' => 'required', 'errors' => ['required' => 'Jenis kelamin wajib diisi']],
      'no_hp' => 'required|numeric|max_length[20]|min_length[5]'
   ];

   public function __construct()
   {
      $this->dosenModel = new dosenModel();
   }

   public function index()
   {
      $data = [
         'title' => 'Data dosen',
         'ctx' => 'dosen',
      ];

      return view('admin/data/data-dosen', $data);
   }

   public function ambilDatadosen()
   {
      $result = $this->dosenModel->getAlldosen();

      $data = [
         'data' => $result,
         'empty' => empty($result)
      ];

      return view('admin/data/list-data-dosen', $data);
   }

   public function formTambahdosen()
   {
      $data = [
         'ctx' => 'dosen',
         'title' => 'Tambah Data dosen'
      ];

      return view('admin/data/create/create-data-dosen', $data);
   }

   public function savedosen()
   {
      // validasi
      if (!$this->validate($this->dosenValidationRules)) {
         $data = [
            'ctx' => 'dosen',
            'title' => 'Tambah Data dosen',
            'validation' => $this->validator,
            'oldInput' => $this->request->getVar()
         ];
         return view('/admin/data/create/create-data-dosen', $data);
      }

      // simpan
      $result = $this->dosenModel->createdosen(
         nuptk: $this->request->getVar('nuptk'),
         nama: $this->request->getVar('nama'),
         jenisKelamin: $this->request->getVar('jk'),
         alamat: $this->request->getVar('alamat'),
         noHp: $this->request->getVar('no_hp'),
      );

      if ($result) {
         session()->setFlashdata([
            'msg' => 'Tambah data berhasil',
            'error' => false
         ]);
         return redirect()->to('/admin/dosen');
      }

      session()->setFlashdata([
         'msg' => 'Gagal menambah data',
         'error' => true
      ]);
      return redirect()->to('/admin/dosen/create/');
   }

   public function formEditdosen($id)
   {
      $dosen = $this->dosenModel->getdosenById($id);

      if (empty($dosen)) {
         throw new PageNotFoundException('Data dosen dengan id ' . $id . ' tidak ditemukan');
      }

      $data = [
         'data' => $dosen,
         'ctx' => 'dosen',
         'title' => 'Edit Data dosen',
      ];

      return view('admin/data/edit/edit-data-dosen', $data);
   }

   public function updatedosen()
   {
      $iddosen = $this->request->getVar('id');

      // validasi
      if (!$this->validate($this->dosenValidationRules)) {
         $data = [
            'data' => $this->dosenModel->getdosenById($iddosen),
            'ctx' => 'dosen',
            'title' => 'Edit Data dosen',
            'validation' => $this->validator,
            'oldInput' => $this->request->getVar()
         ];
         return view('/admin/data/edit/edit-data-dosen', $data);
      }

      // update
      $result = $this->dosenModel->updatedosen(
         id: $iddosen,
         nuptk: $this->request->getVar('nuptk'),
         nama: $this->request->getVar('nama'),
         jenisKelamin: $this->request->getVar('jk'),
         alamat: $this->request->getVar('alamat'),
         noHp: $this->request->getVar('no_hp'),
      );

      if ($result) {
         session()->setFlashdata([
            'msg' => 'Edit data berhasil',
            'error' => false
         ]);
         return redirect()->to('/admin/dosen');
      }

      session()->setFlashdata([
         'msg' => 'Gagal mengubah data',
         'error' => true
      ]);
      return redirect()->to('/admin/dosen/edit/' . $iddosen);
   }

   public function delete($id)
   {
      $result = $this->dosenModel->delete($id);

      if ($result) {
         session()->setFlashdata([
            'msg' => 'Data berhasil dihapus',
            'error' => false
         ]);
         return redirect()->to('/admin/dosen');
      }

      session()->setFlashdata([
         'msg' => 'Gagal menghapus data',
         'error' => true
      ]);
      return redirect()->to('/admin/dosen');
   }
}
