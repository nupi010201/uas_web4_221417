<?php

namespace App\Controllers\Admin;

use App\Models\dosenModel;

use App\Controllers\BaseController;
use App\Models\KehadiranModel;
use App\Models\PresensidosenModel;
use CodeIgniter\I18n\Time;

class DataAbsendosen extends BaseController
{
   protected dosenModel $dosenModel;

   protected PresensidosenModel $presensidosen;

   protected KehadiranModel $kehadiranModel;

   public function __construct()
   {
      $this->dosenModel = new dosenModel();

      $this->presensidosen = new PresensidosenModel();

      $this->kehadiranModel = new KehadiranModel();
   }

   public function index()
   {
      $data = [
         'title' => 'Data Absen dosen',
         'ctx' => 'absen-dosen',
      ];

      return view('admin/absen/absen-dosen', $data);
   }

   public function ambilDatadosen()
   {
      // ambil variabel POST
      $tanggal = $this->request->getVar('tanggal');

      $lewat = Time::parse($tanggal)->isAfter(Time::today());

      $result = $this->presensidosen->getPresensiByTanggal($tanggal);

      $data = [
         'data' => $result,
         'listKehadiran' => $this->kehadiranModel->getAllKehadiran(),
         'lewat' => $lewat
      ];

      return view('admin/absen/list-absen-dosen', $data);
   }

   public function ambilKehadiran()
   {
      $idPresensi = $this->request->getVar('id_presensi');
      $iddosen = $this->request->getVar('id_dosen');

      $data = [
         'presensi' => $this->presensidosen->getPresensiById($idPresensi),
         'listKehadiran' => $this->kehadiranModel->getAllKehadiran(),
         'data' => $this->dosenModel->getdosenById($iddosen)
      ];

      return view('admin/absen/ubah-kehadiran-modal', $data);
   }

   public function ubahKehadiran()
   {
      // ambil variabel POST
      $idKehadiran = $this->request->getVar('id_kehadiran');
      $iddosen = $this->request->getVar('id_dosen');
      $tanggal = $this->request->getVar('tanggal');
      $jamMasuk = $this->request->getVar('jam_masuk');
      $jamKeluar = $this->request->getVar('jam_keluar');
      $keterangan = $this->request->getVar('keterangan');

      $cek = $this->presensidosen->cekAbsen($iddosen, $tanggal);

      $result = $this->presensidosen->updatePresensi(
         $cek == false ? NULL : $cek,
         $iddosen,
         $tanggal,
         $idKehadiran,
         $jamMasuk ?? NULL,
         $jamKeluar ?? NULL,
         $keterangan
      );

      $response['nama_dosen'] = $this->dosenModel->getdosenById($iddosen)['nama_dosen'];

      if ($result) {
         $response['status'] = TRUE;
      } else {
         $response['status'] = FALSE;
      }

      return $this->response->setJSON($response);
   }
}
