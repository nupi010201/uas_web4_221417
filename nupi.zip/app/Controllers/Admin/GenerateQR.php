<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

use App\Models\dosenModel;
use App\Models\KelasModel;
use App\Models\mahasiswaModel;

class GenerateQR extends BaseController
{
   protected mahasiswaModel $mahasiswaModel;
   protected KelasModel $kelasModel;

   protected dosenModel $dosenModel;

   public function __construct()
   {
      $this->mahasiswaModel = new mahasiswaModel();
      $this->kelasModel = new KelasModel();

      $this->dosenModel = new dosenModel();
   }

   public function index()
   {
      $mahasiswa = $this->mahasiswaModel->getAllmahasiswaWithKelas();
      $kelas = $this->kelasModel->getDataKelas();
      $dosen = $this->dosenModel->getAlldosen();

      $data = [
         'title' => 'Generate QR Code',
         'ctx' => 'qr',
         'mahasiswa' => $mahasiswa,
         'kelas' => $kelas,
         'dosen' => $dosen
      ];

      return view('admin/generate-qr/generate-qr', $data);
   }

   public function getmahasiswaByKelas()
   {
      $idKelas = $this->request->getVar('idKelas');

      $mahasiswa = $this->mahasiswaModel->getmahasiswaByKelas($idKelas);

      return $this->response->setJSON($mahasiswa);
   }
}
