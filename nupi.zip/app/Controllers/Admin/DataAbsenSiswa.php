<?php

namespace App\Controllers\Admin;

use App\Models\KelasModel;

use App\Models\mahasiswaModel;

use App\Controllers\BaseController;
use App\Models\KehadiranModel;
use App\Models\PresensimahasiswaModel;
use CodeIgniter\I18n\Time;

class DataAbsenmahasiswa extends BaseController
{
   protected KelasModel $kelasModel;

   protected mahasiswaModel $mahasiswaModel;

   protected KehadiranModel $kehadiranModel;

   protected PresensimahasiswaModel $presensimahasiswa;

   protected string $currentDate;

   public function __construct()
   {
      $this->currentDate = Time::today()->toDateString();

      $this->mahasiswaModel = new mahasiswaModel();

      $this->kehadiranModel = new KehadiranModel();

      $this->kelasModel = new KelasModel();

      $this->presensimahasiswa = new PresensimahasiswaModel();
   }

   public function index()
   {
      $kelas = $this->kelasModel->getDataKelas();

      $data = [
         'title' => 'Data Absen mahasiswa',
         'ctx' => 'absen-mahasiswa',
         'kelas' => $kelas
      ];

      return view('admin/absen/absen-mahasiswa', $data);
   }

   public function ambilDatamahasiswa()
   {
      // ambil variabel POST
      $kelas = $this->request->getVar('kelas');
      $idKelas = $this->request->getVar('id_kelas');
      $tanggal = $this->request->getVar('tanggal');

      $lewat = Time::parse($tanggal)->isAfter(Time::today());

      $result = $this->presensimahasiswa->getPresensiByKelasTanggal($idKelas, $tanggal);

      $data = [
         'kelas' => $kelas,
         'data' => $result,
         'listKehadiran' => $this->kehadiranModel->getAllKehadiran(),
         'lewat' => $lewat
      ];

      return view('admin/absen/list-absen-mahasiswa', $data);
   }

   public function ambilKehadiran()
   {
      $idPresensi = $this->request->getVar('id_presensi');
      $idmahasiswa = $this->request->getVar('id_mahasiswa');

      $data = [
         'presensi' => $this->presensimahasiswa->getPresensiById($idPresensi),
         'listKehadiran' => $this->kehadiranModel->getAllKehadiran(),
         'data' => $this->mahasiswaModel->getmahasiswaById($idmahasiswa)
      ];

      return view('admin/absen/ubah-kehadiran-modal', $data);
   }

   public function ubahKehadiran()
   {
      // ambil variabel POST
      $idKehadiran = $this->request->getVar('id_kehadiran');
      $idmahasiswa = $this->request->getVar('id_mahasiswa');
      $idKelas = $this->request->getVar('id_kelas');
      $tanggal = $this->request->getVar('tanggal');
      $jamMasuk = $this->request->getVar('jam_masuk');
      $jamKeluar = $this->request->getVar('jam_keluar');
      $keterangan = $this->request->getVar('keterangan');

      $cek = $this->presensimahasiswa->cekAbsen($idmahasiswa, $tanggal);

      $result = $this->presensimahasiswa->updatePresensi(
         $cek == false ? NULL : $cek,
         $idmahasiswa,
         $idKelas,
         $tanggal,
         $idKehadiran,
         $jamMasuk ?? NULL,
         $jamKeluar ?? NULL,
         $keterangan
      );

      $response['nama_mahasiswa'] = $this->mahasiswaModel->getmahasiswaById($idmahasiswa)['nama_mahasiswa'];

      if ($result) {
         $response['status'] = TRUE;
      } else {
         $response['status'] = FALSE;
      }

      return $this->response->setJSON($response);
   }
}
