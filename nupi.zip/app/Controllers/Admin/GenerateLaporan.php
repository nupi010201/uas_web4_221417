<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\I18n\Time;
use DateTime;
use DateInterval;
use DatePeriod;

use App\Models\dosenModel;
use App\Models\KelasModel;
use App\Models\PresensidosenModel;
use App\Models\mahasiswaModel;
use App\Models\PresensimahasiswaModel;

class GenerateLaporan extends BaseController
{
   protected mahasiswaModel $mahasiswaModel;
   protected KelasModel $kelasModel;

   protected dosenModel $dosenModel;

   protected PresensimahasiswaModel $presensimahasiswaModel;
   protected PresensidosenModel $presensidosenModel;

   public function __construct()
   {
      $this->mahasiswaModel = new mahasiswaModel();
      $this->kelasModel = new KelasModel();

      $this->dosenModel = new dosenModel();

      $this->presensimahasiswaModel = new PresensimahasiswaModel();
      $this->presensidosenModel = new PresensidosenModel();
   }

   public function index()
   {
      $kelas = $this->kelasModel->getDataKelas();
      $dosen = $this->dosenModel->getAlldosen();

      $mahasiswaPerKelas = [];

      foreach ($kelas as $value) {
         array_push($mahasiswaPerKelas, $this->mahasiswaModel->getmahasiswaByKelas($value['id_kelas']));
      }

      $data = [
         'title' => 'Generate Laporan',
         'ctx' => 'laporan',
         'mahasiswaPerKelas' => $mahasiswaPerKelas,
         'kelas' => $kelas,
         'dosen' => $dosen
      ];

      return view('admin/generate-laporan/generate-laporan', $data);
   }

   public function generateLaporanmahasiswa()
   {
      $idKelas = $this->request->getVar('kelas');
      $mahasiswa = $this->mahasiswaModel->getmahasiswaByKelas($idKelas);
      $type = $this->request->getVar('type');

      if (empty($mahasiswa)) {
         session()->setFlashdata([
            'msg' => 'Data mahasiswa kosong!',
            'error' => true
         ]);
         return redirect()->to('/admin/laporan');
      }

      $kelas = $this->kelasModel->where(['id_kelas' => $idKelas])
         ->join('tb_jurusan', 'tb_kelas.id_jurusan = tb_jurusan.id', 'left')
         ->first();

      $bulan = $this->request->getVar('tanggalmahasiswa');

      // hari pertama dalam 1 bulan
      $begin = new Time($bulan, locale: 'id');
      // tanggal terakhir dalam 1 bulan
      $end = (new DateTime($begin->format('Y-m-t')))->modify('+1 day');
      // interval 1 hari
      $interval = DateInterval::createFromDateString('1 day');
      // buat array dari semua hari di bulan
      $period = new DatePeriod($begin, $interval, $end);

      $arrayTanggal = [];
      $dataAbsen = [];

      foreach ($period as $value) {
         // kecualikan hari sabtu dan minggu
         if (!($value->format('D') == 'Sat' || $value->format('D') == 'Sun')) {
            $lewat = Time::parse($value->format('Y-m-d'))->isAfter(Time::today());

            $absenByTanggal = $this->presensimahasiswaModel
               ->getPresensiByKelasTanggal($idKelas, $value->format('Y-m-d'));

            $absenByTanggal['lewat'] = $lewat;

            array_push($dataAbsen, $absenByTanggal);
            array_push($arrayTanggal, Time::createFromInstance($value, locale: 'id'));
         }
      }

      $laki = 0;

      foreach ($mahasiswa as $value) {
         if ($value['jenis_kelamin'] != 'Perempuan') {
            $laki++;
         }
      }

      $data = [
         'tanggal' => $arrayTanggal,
         'bulan' => $begin->toLocalizedString('MMMM'),
         'listAbsen' => $dataAbsen,
         'listmahasiswa' => $mahasiswa,
         'jumlahmahasiswa' => [
            'laki' => $laki,
            'perempuan' => count($mahasiswa) - $laki
         ],
         'kelas' => $kelas,
         'grup' => "kelas " . $kelas['kelas'] . " " . $kelas['jurusan'],
      ];

      if ($type == 'doc') {
         $this->response->setHeader('Content-type', 'application/vnd.ms-word');
         $this->response->setHeader(
            'Content-Disposition',
            'attachment;Filename=laporan_absen_' . $kelas['kelas'] . " " . $kelas['jurusan'] . '_' . $begin->toLocalizedString('MMMM-Y') . '.doc'
         );

         return view('admin/generate-laporan/laporan-mahasiswa', $data);
      }

      return view('admin/generate-laporan/laporan-mahasiswa', $data) . view('admin/generate-laporan/topdf');
   }

   public function generateLaporandosen()
   {
      $dosen = $this->dosenModel->getAlldosen();
      $type = $this->request->getVar('type');

      if (empty($dosen)) {
         session()->setFlashdata([
            'msg' => 'Data dosen kosong!',
            'error' => true
         ]);
         return redirect()->to('/admin/laporan');
      }

      $bulan = $this->request->getVar('tanggaldosen');

      // hari pertama dalam 1 bulan
      $begin = new Time($bulan, locale: 'id');
      // tanggal terakhir dalam 1 bulan
      $end = (new DateTime($begin->format('Y-m-t')))->modify('+1 day');
      // interval 1 hari
      $interval = DateInterval::createFromDateString('1 day');
      // buat array dari semua hari di bulan
      $period = new DatePeriod($begin, $interval, $end);

      $arrayTanggal = [];
      $dataAbsen = [];

      foreach ($period as $value) {
         // kecualikan hari sabtu dan minggu
         if (!($value->format('D') == 'Sat' || $value->format('D') == 'Sun')) {
            $lewat = Time::parse($value->format('Y-m-d'))->isAfter(Time::today());

            $absenByTanggal = $this->presensidosenModel
               ->getPresensiByTanggal($value->format('Y-m-d'));

            $absenByTanggal['lewat'] = $lewat;

            array_push($dataAbsen, $absenByTanggal);
            array_push($arrayTanggal, Time::createFromInstance($value, locale: 'id'));
         }
      }

      $laki = 0;

      foreach ($dosen as $value) {
         if ($value['jenis_kelamin'] != 'Perempuan') {
            $laki++;
         }
      }

      $data = [
         'tanggal' => $arrayTanggal,
         'bulan' => $begin->toLocalizedString('MMMM'),
         'listAbsen' => $dataAbsen,
         'listdosen' => $dosen,
         'jumlahdosen' => [
            'laki' => $laki,
            'perempuan' => count($dosen) - $laki
         ],
         'grup' => 'dosen',
      ];

      if ($type == 'doc') {
         $this->response->setHeader('Content-type', 'application/vnd.ms-word');
         $this->response->setHeader(
            'Content-Disposition',
            'attachment;Filename=laporan_absen_dosen_' . $begin->toLocalizedString('MMMM-Y') . '.doc'
         );

         return view('admin/generate-laporan/laporan-dosen', $data);
      }

      return view('admin/generate-laporan/laporan-dosen', $data) . view('admin/generate-laporan/topdf');
   }
}
