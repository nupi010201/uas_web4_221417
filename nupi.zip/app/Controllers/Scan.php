<?php

namespace App\Controllers;

use CodeIgniter\I18n\Time;
use App\Models\dosenModel;
use App\Models\mahasiswaModel;
use App\Models\PresensidosenModel;
use App\Models\PresensimahasiswaModel;
use App\Libraries\enums\TipeUser;

class Scan extends BaseController
{
   protected mahasiswaModel $mahasiswaModel;
   protected dosenModel $dosenModel;

   protected PresensimahasiswaModel $presensimahasiswaModel;
   protected PresensidosenModel $presensidosenModel;

   public function __construct()
   {
      $this->mahasiswaModel = new mahasiswaModel();
      $this->dosenModel = new dosenModel();
      $this->presensimahasiswaModel = new PresensimahasiswaModel();
      $this->presensidosenModel = new PresensidosenModel();
   }

   public function index($t = 'Masuk')
   {
      $data = ['waktu' => $t, 'title' => 'Absensi mahasiswa dan dosen Berbasis QR Code'];
      return view('scan/scan', $data);
   }

   public function cekKode()
   {
      // ambil variabel POST
      $uniqueCode = $this->request->getVar('unique_code');
      $waktuAbsen = $this->request->getVar('waktu');

      $status = false;
      $type = TipeUser::mahasiswa;

      // cek data mahasiswa di database
      $result = $this->mahasiswaModel->cekmahasiswa($uniqueCode);

      if (empty($result)) {
         // jika cek mahasiswa gagal, cek data dosen
         $result = $this->dosenModel->cekdosen($uniqueCode);

         if (!empty($result)) {
            $status = true;

            $type = TipeUser::dosen;
         } else {
            $status = false;

            $result = NULL;
         }
      } else {
         $status = true;
      }

      if (!$status) { // data tidak ditemukan
         return $this->showErrorView('Data tidak ditemukan');
      }

      // jika data ditemukan
      switch ($waktuAbsen) {
         case 'masuk':
            return $this->absenMasuk($type, $result);
            break;

         case 'pulang':
            return $this->absenPulang($type, $result);
            break;

         default:
            return $this->showErrorView('Data tidak valid');
            break;
      }
   }

   public function absenMasuk($type, $result)
   {
      // data ditemukan
      $data['data'] = $result;
      $data['waktu'] = 'masuk';

      $date = Time::today()->toDateString();
      $time = Time::now()->toTimeString();

      // absen masuk
      switch ($type) {
         case TipeUser::dosen:
            $iddosen =  $result['id_dosen'];
            $data['type'] = TipeUser::dosen;

            $sudahAbsen = $this->presensidosenModel->cekAbsen($iddosen, $date);

            if ($sudahAbsen) {
               $data['presensi'] = $this->presensidosenModel->getPresensiById($sudahAbsen);
               return $this->showErrorView('Anda sudah absen hari ini', $data);
            }

            $this->presensidosenModel->absenMasuk($iddosen, $date, $time);

            $data['presensi'] = $this->presensidosenModel->getPresensiByIddosenTanggal($iddosen, $date);

            return view('scan/scan-result', $data);

         case TipeUser::mahasiswa:
            $idmahasiswa =  $result['id_mahasiswa'];
            $idKelas =  $result['id_kelas'];
            $data['type'] = TipeUser::mahasiswa;

            $sudahAbsen = $this->presensimahasiswaModel->cekAbsen($idmahasiswa, Time::today()->toDateString());

            if ($sudahAbsen) {
               $data['presensi'] = $this->presensimahasiswaModel->getPresensiById($sudahAbsen);
               return $this->showErrorView('Anda sudah absen hari ini', $data);
            }

            $this->presensimahasiswaModel->absenMasuk($idmahasiswa, $date, $time, $idKelas);

            $data['presensi'] = $this->presensimahasiswaModel->getPresensiByIdmahasiswaTanggal($idmahasiswa, $date);

            return view('scan/scan-result', $data);

         default:
            return $this->showErrorView('Tipe tidak valid');
      }
   }

   public function absenPulang($type, $result)
   {
      // data ditemukan
      $data['data'] = $result;
      $data['waktu'] = 'pulang';

      $date = Time::today()->toDateString();
      $time = Time::now()->toTimeString();

      // absen pulang
      switch ($type) {
         case TipeUser::dosen:
            $iddosen =  $result['id_dosen'];
            $data['type'] = TipeUser::dosen;

            $sudahAbsen = $this->presensidosenModel->cekAbsen($iddosen, $date);

            if (!$sudahAbsen) {
               return $this->showErrorView('Anda belum absen hari ini', $data);
            }

            $this->presensidosenModel->absenKeluar($sudahAbsen, $time);

            $data['presensi'] = $this->presensidosenModel->getPresensiById($sudahAbsen);

            return view('scan/scan-result', $data);

         case TipeUser::mahasiswa:
            $idmahasiswa =  $result['id_mahasiswa'];
            $data['type'] = TipeUser::mahasiswa;

            $sudahAbsen = $this->presensimahasiswaModel->cekAbsen($idmahasiswa, $date);

            if (!$sudahAbsen) {
               return $this->showErrorView('Anda belum absen hari ini', $data);
            }

            $this->presensimahasiswaModel->absenKeluar($sudahAbsen, $time);

            $data['presensi'] = $this->presensimahasiswaModel->getPresensiById($sudahAbsen);

            return view('scan/scan-result', $data);
         default:
            return $this->showErrorView('Tipe tidak valid');
      }
   }

   public function showErrorView(string $msg = 'no error message', $data = NULL)
   {
      $errdata = $data ?? [];
      $errdata['msg'] = $msg;

      return view('scan/error-scan-result', $errdata);
   }
}
