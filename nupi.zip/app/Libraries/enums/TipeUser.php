<?php

namespace App\Libraries\enums;

enum TipeUser: string
{
  case mahasiswa = 'id_mahasiswa';
  case dosen = 'id_dosen';
}
